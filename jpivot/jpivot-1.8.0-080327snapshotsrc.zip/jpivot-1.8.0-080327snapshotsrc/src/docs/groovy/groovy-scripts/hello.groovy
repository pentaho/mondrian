
output = [URL:"http://url/hello.i18n", Value:input["Store Name"]]
