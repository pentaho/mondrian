package com.tonbeller.tbutils.res;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * initial provider. looks up variables
 * <ol>
 * <li>in JNDI java:/comp/env context</li>
 * <li>resfactory.properties in root classpath</li>
 * <li>System.getProperty()</li>
 * </ol>
 * in that order.
 * 
 * @author av
 */
public class JNDIInitialProvider extends CompositeResourceProvider implements InitialProvider {
  public JNDIInitialProvider() {
    add(new JNDIResourceProvider());
    try {
      ResourceBundle resb = ResourceBundle.getBundle(RESFACTORY);
      add(new BundleResourceProvider(resb));
    }
    catch (MissingResourceException e) {
      // ignore
    }
    add(new SystemResourceProvider());
  }
}