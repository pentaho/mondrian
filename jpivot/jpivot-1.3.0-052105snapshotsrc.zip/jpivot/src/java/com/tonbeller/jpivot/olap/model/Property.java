/*
 * ====================================================================
 * This software is subject to the terms of the Common Public License
 * Agreement, available at the following URL:
 *   http://www.opensource.org/licenses/cpl.html .
 * Copyright (C) 2003-2004 TONBELLER AG.
 * All Rights Reserved.
 * You must accept the terms of that agreement to use this software.
 * ====================================================================
 *
 * $Id: Property.java,v 1.12 2005/02/23 10:26:30 av Exp $
 */
package com.tonbeller.jpivot.olap.model;


/**
 * Property of a Member
 * @author av
 */
public interface Property extends Visitable, Decorator, Displayable, PropertyHolder, Alignable {
  /**
   * @return the name of the Property
   */
  String getName();
  
  /**
   * the value of the property
   */
  String getValue();
  
}
