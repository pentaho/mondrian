/*
 * ====================================================================
 * This software is subject to the terms of the Common Public License
 * Agreement, available at the following URL:
 *   http://www.opensource.org/licenses/cpl.html .
 * Copyright (C) 2003-2004 TONBELLER AG.
 * All Rights Reserved.
 * You must accept the terms of that agreement to use this software.
 * ====================================================================
 *
 * $Id: HierarchyItemClickHandler.java,v 1.8 2004/11/26 16:51:48 hh Exp $
 */
package com.tonbeller.jpivot.navigator.hierarchy;

import com.tonbeller.wcf.controller.RequestContext;
import com.tonbeller.wcf.selection.SelectionModel;

/**
 * called when the user clicks on a HierarchyItem
 * 
 * @author av
 */
public interface HierarchyItemClickHandler {
  void itemClicked(RequestContext context, HierarchyItem item, SelectionModel selection, boolean allowChangeOrder);
}
