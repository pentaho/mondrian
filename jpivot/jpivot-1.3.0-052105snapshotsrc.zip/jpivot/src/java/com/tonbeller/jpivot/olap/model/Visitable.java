/*
 * ====================================================================
 * This software is subject to the terms of the Common Public License
 * Agreement, available at the following URL:
 *   http://www.opensource.org/licenses/cpl.html .
 * Copyright (C) 2003-2004 TONBELLER AG.
 * All Rights Reserved.
 * You must accept the terms of that agreement to use this software.
 * ====================================================================
 *
 * $Id: Visitable.java,v 1.5 2004/11/26 16:51:48 hh Exp $
 */
package com.tonbeller.jpivot.olap.model;

/**
 * Created on 29.10.2002
 * 
 * @author av
 */
public interface Visitable {
  void accept(Visitor visitor);
}
