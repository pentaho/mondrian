package com.tonbeller.wcf.form;

/**
 * @author av
 */
public class ActionReferenceException extends RuntimeException {

}
