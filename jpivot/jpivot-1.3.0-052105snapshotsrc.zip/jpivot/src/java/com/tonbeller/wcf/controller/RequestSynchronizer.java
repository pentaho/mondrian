/*
 * ====================================================================
 * This software is subject to the terms of the Common Public License
 * Agreement, available at the following URL:
 *   http://www.opensource.org/licenses/cpl.html .
 * Copyright (C) 2003-2004 TONBELLER AG.
 * All Rights Reserved.
 * You must accept the terms of that agreement to use this software.
 * ====================================================================
 *
 * $Id: RequestSynchronizer.java,v 1.9 2004/11/26 17:13:08 hh Exp $
 */
package com.tonbeller.wcf.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 *  serializes http requests. Ensures that there is max one request per session
 */
public class RequestSynchronizer {
  private static final String WEBKEY = "requestSynchronizer";
  private static Logger logger = Logger.getLogger(RequestSynchronizer.class);

  /** 
   * the uri that shows the content of the current request. The busy.jsp
   * will redirect to this uri. 
   */
  private String resultURI = null;
  /**
   * true if there is a request currently active and other requests
   * shall be redirected to the busy page.
   */
  private boolean insideRequest = false;

  RequestSynchronizer() {
  }

  public static synchronized RequestSynchronizer instance(HttpServletRequest request) {
    HttpSession session = request.getSession(true);
    RequestSynchronizer rsync = (RequestSynchronizer) session.getAttribute(WEBKEY);
    if (rsync == null) {
      rsync = new RequestSynchronizer();
      session.setAttribute(WEBKEY, rsync);
    }
    return rsync;
  }

  public interface Handler {

    /**
     * this request that should be processed normally
     */
    void normalRequest() throws Exception;

    /**
     * this should redirect to a page saying "your result is computed, please wait ... ".
     * The page could then redirect to RequestSynchronizer.instance(session).getResultURI()
     * to show the result.
     * @param redirect true, when the current page is not the busy page. false, if
     * the current page already is the busy page.
     */
    void showBusyPage(boolean redirect) throws Exception;

    /**
     * returns the URI of the result that the busy page should redirect to
     */
    String getResultURI();

    /**
     * true if this request is the busy page
     */
    boolean isBusyPage();
  }

  private synchronized boolean startNormalRequest(Handler handler) {
    if (logger.isInfoEnabled())
      logInfo("start-1");
    if (insideRequest)
      return false;
    insideRequest = true;
    resultURI = handler.getResultURI();
    if (logger.isInfoEnabled())
      logInfo("start-2");
    return true;
  }

  private void logInfo(String id) {
    logger.info("Log " + id + " Thread = " + Thread.currentThread().getName() + ", resultURI = " + resultURI + ", insideRequest = " + insideRequest);    
  }
  
  private synchronized void endNormalRequest() {
    if (logger.isInfoEnabled())
      logInfo("end");
    insideRequest = false;
  }

  public void handleRequest(Handler handler) throws Exception {
    // if this is the busy page, just display
    if (handler.isBusyPage()) {
      handler.showBusyPage(false);
      if (logger.isInfoEnabled())
        logInfo("handle-busy-false");
      return;
    }
    
    if (startNormalRequest(handler)) {
      // no other requests active, run this request normally
      try {
        if (logger.isInfoEnabled())
          logInfo("handle-normal");
        handler.normalRequest();
      } finally {
        endNormalRequest();
      }
    } else {
      // another request is still active, redirect to busy page
      if (logger.isInfoEnabled())
        logInfo("handle-busy-true");
      handler.showBusyPage(true);
    }
  }

  public String getResultURI() {
    return resultURI;
  }
}