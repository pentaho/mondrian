/*
 * ====================================================================
 * This software is subject to the terms of the Common Public License
 * Agreement, available at the following URL:
 *   http://www.opensource.org/licenses/cpl.html .
 * Copyright (C) 2003-2004 TONBELLER AG.
 * All Rights Reserved.
 * You must accept the terms of that agreement to use this software.
 * ====================================================================
 *
 * $Id: Controller.java,v 1.12 2004/12/21 17:26:37 av Exp $
 */
package com.tonbeller.wcf.controller;

import javax.servlet.http.HttpSession;

/**
 * provides access to the dispatcher and next view
 */
public abstract class Controller implements RequestListener {

  public static Controller instance(HttpSession session) {
    return WcfController.instance(session);
  }
  
  public abstract void addRequestListener(RequestListener l);
  public abstract void removeRequestListener(RequestListener l);
  public abstract void setNextView(String uri);
  public abstract String getNextView();
}
