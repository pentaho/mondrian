package com.clarmont.olap.components;

import com.tonbeller.wcf.component.Component;
import com.tonbeller.wcf.component.ComponentTag;
import com.tonbeller.wcf.controller.RequestContext;


/**
 * creates a ChartComponent
 * @author Robin Bagot
 */
public class PrintComponentTag extends ComponentTag {
	String query;

  /**
   * creates a Print Component
   */
  public Component createComponent(RequestContext context) throws Exception {
	return new PrintComponent(id, context);
  }
  
}
