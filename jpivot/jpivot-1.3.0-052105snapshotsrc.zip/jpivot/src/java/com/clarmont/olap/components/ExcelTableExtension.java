package com.clarmont.olap.components;

import com.tonbeller.jpivot.table.TableComponent;
import com.tonbeller.jpivot.table.TableComponentExtensionSupport;
import com.tonbeller.wcf.controller.RequestContext;

/**
 */
public class ExcelTableExtension extends TableComponentExtensionSupport {
  public static final String ID = "excel";

  public String getId() {
    return ID;
  }

  public void initialize(RequestContext context, TableComponent table) throws Exception {
    super.initialize(context, table);
    ExcelCellBuilderDecorator cbd = new ExcelCellBuilderDecorator(table.getCellBuilder());
    table.setCellBuilder(cbd);
  }
  
}